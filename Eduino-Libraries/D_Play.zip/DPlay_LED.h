#include <Arduino.h>

#define		ON		HIGH
#define		OFF		LOW

void LED(int PinNum, int State);
void LED_Brightless(int PinNum, int Brightless);

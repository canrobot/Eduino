#include <Arduino.h>

float read_temperature(int PinNum);


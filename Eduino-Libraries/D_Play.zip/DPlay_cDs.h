#include <Arduino.h>

#define		BRIGHT		HIGH
#define		DARK		LOW

int Brightless_Divide(int PinNum);
int Brightless(int PinNum);

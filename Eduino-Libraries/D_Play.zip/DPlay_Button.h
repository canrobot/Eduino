#include <Arduino.h>

#define		ON		HIGH
#define		OFF		LOW

int Button_Pressed(int PinNum);


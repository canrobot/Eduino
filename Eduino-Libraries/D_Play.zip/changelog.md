## 2.0.1 - 2015/06/26 - [Release](https://github.com/shirriff/Arduino-IRremote/releases/tag/BETA)
- Separated protocols into individual files
- Lots of code clean up
- Possible bug fixes

